﻿namespace WindowsFormsApp2
{


    partial class DSAlumnos
    {
    }
}

namespace WindowsFormsApp2.DSAlumnosTableAdapters {
    
    
    public partial class AlumnosTableAdapter {
    }
}
